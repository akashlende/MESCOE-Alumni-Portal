const firebaseConfig = {
	apiKey: "AIzaSyCBcqL0b8LqsURhdUOmmSBcntqXSI6uu7g",
	authDomain: "mescoe-alumni.firebaseapp.com",
	databaseURL: "https://mescoe-alumni.firebaseio.com",
	projectId: "mescoe-alumni",
	storageBucket: "mescoe-alumni.appspot.com",
	messagingSenderId: "332958193506",
	appId: "1:332958193506:web:b218c9102289cb36f0fe3b"
};